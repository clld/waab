
AfBo: A world-wide survey of affix borrowing data dump
======================================================

Data of AfBo: A world-wide survey of affix borrowing is published under the following license:
http://creativecommons.org/licenses/by/3.0/

It should be cited as

Seifart, Frank. 2013.
AfBo: A world-wide survey of affix borrowing.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://afbo.info, Accessed on 2014-08-05.)


This package contains files in csv format [1] with corresponding schema descriptions in
JSON table schema [2] format, representing rows in database tables of the AfBo: A world-wide survey of affix borrowing web
application [3,4].

[1] http://csvlint.io/about
[2] http://dataprotocols.org/json-table-schema/
[3] http://afbo.info
[4] https://github.com/clld/afbo
